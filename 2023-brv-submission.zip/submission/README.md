# BRV Winter Term 2023 Submission Template

Name:
Marvin Spiegel

Matriculation Number:
3721771
